<?php
/**
 * SQL statement for NIMH clinical studies.
 *
 * This function creates the database SQL query used for getting all of the necessary data for
 * Clinical Studies sponsored by the NIMH.
 *
 * @since 1.0.0
 * 02/16/2022 - Initial creation (David Castano)
 *
 * @return string SQL select statement
 */
function createQuery(){
$aactQuery = "select studies.nct_id as nct_id, studies.study_type as type, studies.brief_title as title, studies.official_title as official_title,".
"studies.start_date as start_date, detailed_descriptions.description as desc, brief_summaries.description as summary,".
"conditions.id as conditions_id, conditions.name as condition,".
"browse_conditions.id as browse_conditions_id, browse_conditions.mesh_term as term,".
"eligibilities.id as eligibilities_id, eligibilities.sampling_method as sampling_method,".
"eligibilities.gender as gender, eligibilities.gender_based as gender_based, eligibilities.gender_description as gender_description,".
"eligibilities.minimum_age as min_age, eligibilities.maximum_age as max_age, eligibilities.healthy_volunteers as healthy_volunteers,".
"eligibilities.population as population, eligibilities.criteria as criteria,".
"facilities.id as facilities_id, facilities.name as facilities_name, facilities.status as status,".
"facilities.city as city, facilities.state as state, facilities.zip as zip, facilities.country as country,".
"keywords.id as keywords_id, keywords.name as keyword, ". "links.url as link ".
"from sponsors ".
"inner join studies on sponsors.nct_id = studies.nct_id and studies.overall_status = 'Recruiting' ".
"left join detailed_descriptions on sponsors.nct_id = detailed_descriptions.nct_id ".
"left join brief_summaries on sponsors.nct_id = brief_summaries.nct_id ".
"left join conditions on sponsors.nct_id = conditions.nct_id ".
"left join browse_conditions on sponsors.nct_id = browse_conditions.nct_id ".
"left join eligibilities on sponsors.nct_id = eligibilities.nct_id ".
"left join links on sponsors.nct_id = links.nct_id ".
"left join facilities on sponsors.nct_id = facilities.nct_id and facilities.status = 'Recruiting' ".
"left join keywords on sponsors.nct_id = keywords.nct_id ".
"where sponsors.name ='National Institute of Mental Health (NIMH)'";
return $aactQuery;
}

/**
 * Executes SQL query and calls other functions for building, sorting, and creating HTML files.
 *
 * This function main objective is to query the database using the SQL statement from the createQuery() function.
 * It logs if there is any issues connecting to the database. Otherwise it process each query result by
 * calling the functions that build the NIMH clinical studies objects. Once all results are processed,
 * the studies are sorted by date. Then they are filtered by keywords, gender, and unmatched results.
 */
function runQuery(){
$query = createQuery();
    if ($GLOBALS['aactDB']) {
        $result = pg_query($GLOBALS['aactDB'], $query);
        if (!$result) {
            $file = 'error.log';
            $date = date('Y-m-d H:i:s');
            $error = "ERROR: ".$date." AACT Query failed.\n";
            file_put_contents($file, $error, FILE_APPEND | LOCK_EX);
        } else {
            $studies = array();
// Build the array of results.  The reason an array is built first is because some records
// may have the same study id but have multiple locations, populations, terms, conditions and keywords
            while ($data = pg_fetch_object($result)) {
                $study_id = $data->nct_id;
                if (array_key_exists($study_id, $studies)) {
                    $studies = checkAndAssignValue($studies, $data, $study_id);
                } else {
                    $studies = assignValues($studies, $study_id, $data);
                }
            }
            $list = sortStudiesByDate($studies);
            compareRefKeytoQueriedObjects($GLOBALS['conditions'], $list);
            identifyStudiesbyMiscDisorders($list);
            identifyStudiesbyGender($list);
            cleanFiles();
        }
    }else{
        $file = 'error.log';
        $date = date('Y-m-d H:i:s');
        $error = "ERROR: ".$date." Could not connect to the AACT database.\n";
        file_put_contents($file, $error, FILE_APPEND | LOCK_EX);
    }
}

/**
 * Analyzes queried object for existing values of object in the NIMH studies array.
 *
 * This function accepts $studies_array, where we store the array of results, it also
 * accepts the $data_object, this is a single instance(row) of the queried results, and finally
 * it accepts the $study_identifier, for referring to the result that already exists in the $studies_array.
 * It checks for certain object properties, and then it proceeds to assign their value.
 * It returns the updated $studies_array.
 *
 * @param $studies_array
 * @param $data_object
 * @param $study_identifier
 * @return mixed
 */
function checkAndAssignValue($studies_array, $data_object, $study_identifier){
    $place_id = $data_object->facilities_id;

    if(!empty($place_id)){
        $found_place = FALSE;
        foreach($studies_array[$study_identifier]['locations'] as $location){
            if($location['place_id'] == $place_id){
                $found_place = TRUE;
                break;
            }
        }

        if(!$found_place){
            $studies_array[$study_identifier]['locations'][] = array('place_id'=>$place_id,'city'=>trim($data_object->city), 'state'=>trim($data_object->state), 'country'=>trim($data_object->country));
        }
    }

    $pop_id = $data_object->eligibilities_id;

    if(!empty($pop_id)){
        $found_pop = FALSE;
        foreach($studies_array[$study_identifier]['populations'] as $population){
            if($population['pop_id'] == $pop_id){
                $found_pop = TRUE;
                break;
            }
        }

        if(!$found_pop){
            $studies_array[$study_identifier]['populations'][] = array('pop_id'=>$pop_id, 'gender'=>trim($data_object->gender), 'min'=>trim($data_object->min_age), 'max'=>trim($data_object->max_age), 'hv'=>trim($data_object->healthy_volunteers));
        }
    }

    $term_id = $data_object->browse_conditions_id;

    if(!empty($term_id)){
        $found_term = FALSE;
        foreach($studies_array[$study_identifier]['terms'] as $term){
            if($term['term_id'] == $term_id){
                $found_term = TRUE;
                break;
            }
        }

        if(!$found_term){
            $studies_array[$study_identifier]['terms'][] = array('term_id'=>$term_id, 'term'=>$data_object->term);
        }
    }

    $condition_id = $data_object->conditions_id;

    if(!empty($condition_id)){
        $found_condition = FALSE;
        foreach($studies_array[$study_identifier]['conditions'] as $condition){
            if($condition['condition_id'] == $condition_id){
                $found_condition = TRUE;
                break;
            }
        }

        if(!$found_condition){
            $studies_array[$study_identifier]['conditions'][] = array('condition_id'=>$condition_id, 'condition'=>$data_object->condition);
        }
    }

    $keyword_id = $data_object->keywords_id;

    if(!empty($keyword_id)){
        $found_keyword = FALSE;
        foreach($studies_array[$study_identifier]['keywords'] as $keyword){
            if($keyword['keyword_id'] == $keyword_id){
                $found_keyword = TRUE;
                break;
            }
        }

        if(!$found_keyword){
            $studies_array[$study_identifier]['keywords'][] = array('keyword_id'=>$keyword_id, 'keyword'=>$data_object->keyword);
        }
    }
    return $studies_array;
}

/**
 * It creates an object in the NIMH studies array from the object provided.
 *
 * This function accepts $studies_array, where we store the array of results, it also
 * accepts the $data_object, this is a single instance(row) of the queried results, and finally
 * it accepts the $study_identifier, for referring to the result that already exists in the $studies_array.
 * A new object is pushed to the $studies_array with all of the required properties, and if some properties
 * do not have values, it still creates their section for future reference.
 *
 * @param $studies_array
 * @param $study_identifier
 * @param $data_object
 * @return mixed
 */
function assignValues($studies_array, $study_identifier, $data_object){
    //var_dump($data_object);
    $studies_array[$study_identifier]['nct_id'] = trim($data_object->nct_id);
    $studies_array[$study_identifier]['title'] = trim($data_object->title);
    $studies_array[$study_identifier]['date'] = trim($data_object->start_date);
    $studies_array[$study_identifier]['type'] = trim($data_object->type);
    $studies_array[$study_identifier]['summary'] = trim($data_object->summary);
    $studies_array[$study_identifier]['locations'] = array();
    $studies_array[$study_identifier]['populations'] = array();
    $studies_array[$study_identifier]['terms'] = array();
    $studies_array[$study_identifier]['conditions'] = array();
    $studies_array[$study_identifier]['keywords'] = array();

    $place_id = $data_object->facilities_id;

    if(!empty($place_id)){
        $studies_array[$study_identifier]['locations'][] = array('place_id'=>$place_id,'city'=>trim($data_object->city), 'state'=>trim($data_object->state), 'country'=>trim($data_object->country));
    }

    $pop_id = $data_object->eligibilities_id;

    if(!empty($pop_id)){
        $studies_array[$study_identifier]['populations'][] = array('pop_id'=>$pop_id, 'gender'=>trim($data_object->gender), 'min'=>trim($data_object->min_age), 'max'=>trim($data_object->max_age), 'hv'=>trim($data_object->healthy_volunteers));
    }

    $term_id = $data_object->browse_conditions_id;

    if(!empty($term_id)){
        $studies_array[$study_identifier]['terms'][] = array('term_id'=>$term_id, 'term'=>trim($data_object->term));
    }

    $condition_id = $data_object->conditions_id;

    if(!empty($condition_id)){
        $studies_array[$study_identifier]['conditions'][] = array('condition_id'=>$condition_id, 'condition'=>trim($data_object->condition));
    }

    $keyword_id = $data_object->keywords_id;

    if(!empty($keyword_id)){
        $studies_array[$study_identifier]['keywords'][] = array('keyword_id'=>$keyword_id, 'keyword'=>trim($data_object->keyword));
    }

    return $studies_array;
}

/**
 * It sorts an array by date, and it returns the result.
 *
 * This functions accepts an array, and it sorts the objects of the array based on the date
 * in a descending order. The studies are arranged from the latest and most recent one to the oldest one.
 * It returns the array organized in this order.
 *
 * @param $studies
 * @return mixed
 */
function sortStudiesByDate($studies){
    $dates = array();

    foreach ($studies as $nctid => $data){
        $dates[$nctid] = $data['date'];
    }

    array_multisort($dates, SORT_DESC, $studies);

    return $studies;
}

/**
 * It filters studies by keywords associated with mental health disorders.
 *
 * This function accepts $reference, an array of objects that contains keywords for mental health disorders, and it
 * accepts $studies, where we store the array of study results objects. It looks if the study keywords matches one
 * of the keywords in the $reference array of objects for that specific mental health disorder array of keywords.
 * If it does, then it is assigned to the $condition array which contains all of the studies that have matched;
 * otherwise, it checks the next object for matches. At the same time, we check if the study is part of the global
 * $studiesFound array variable, this is a step required for filtering studies that are not a match for any of the
 * mental health disorders keywords array. After, checking all of the studies objects for a specific mental health
 * disorder
 *
 *
 * @param $reference
 * @param $studies
 */
function compareRefKeytoQueriedObjects($reference, $studies){

    foreach ($reference as $disorder){
        $condition = array();
        $cond_name = $disorder->name;

        foreach ($disorder as $key => $value) {

            foreach ($studies as $obj) {

                $array_length = count($obj['keywords']);
                $terms_array_length = count($obj['terms']);

                $keyword = $value;

                for ($i = 0; $i < $array_length; $i++) {
                    $obj_keyword = strtolower($obj['keywords'][$i]['keyword']);

                    if (array_key_exists($obj['nct_id'], $condition)) {

                        break;
                    } else {
                        if ($keyword == $obj_keyword){

                            $condition[$obj['nct_id']] = $obj;
                            if (!in_array($obj['nct_id'],$GLOBALS['studiesFound'])){
                                array_push($GLOBALS['studiesFound'], $obj['nct_id']);

                            }
                        }
                    }
                }
                for ($i = 0; $i < $terms_array_length; $i++) {
                    $obj_term = strtolower($obj['terms'][$i]['term']);

                    if(array_key_exists($obj['nct_id'], $condition)) {
                        break;
                    }else{
                        if($keyword==$obj_term){
                            $condition[$obj['nct_id']] = $obj;
                            if (!in_array($obj['nct_id'],$GLOBALS['studiesFound'])){
                                array_push($GLOBALS['studiesFound'], $obj['nct_id']);
                            }
                        }
                    }
                }
            }
        }
        createHTMLDoc($condition, $cond_name);
    }

}

/**
 * It filters studies by gender, and it sends the results for creating a HTML doc.
 *
 * This function accepts $studies, where we store the array of study results. It looks if the study object gender
 * matches male, if it does, then the object is pushed to the $maleStudies array; otherwise, it checks if the gender for
 * that study is female, if it does, then the object is pushed to the $femaleStudies array. Once, all of the studies are
 * filtered, the $maleStudies and $femaleStudies arrays are sent for creating a HTML document, separately.
 *
 * @param $studies
 */
function identifyStudiesbyGender($studies){
    $maleStudies = array();
    $femStudies = array();
    $male = "1017";
    $female = "1018";

    foreach ($studies as $obj) {
        $gender = strtolower($obj['populations'][0]['gender']);

        if($gender=='male'){
            if(!array_key_exists($obj['nct_id'],$maleStudies)){

                $maleStudies[$obj['nct_id']] = $obj;
            }
        }else{
            if($gender=='female') {
                if (!array_key_exists($obj['nct_id'], $femStudies)) {
                    $femStudies[$obj['nct_id']] = $obj;
                }
            }
        }
    }

    createHTMLDoc($maleStudies, $male);
    createHTMLDoc($femStudies, $female);
}

/**
 * It creates an array of unmatched studies, and it sends the results for creating a HTML doc.
 *
 * This function accepts $studies, where we store the array of study results. It creates a miscellaneous array of studies,
 * where we store the results that are not part of the global variable $studiesFound; this array is populated by
 * comparing the id of the $studies array against those of the $studiesFound, if the study id is not in the $studiesFound
 * then it is pushed to the miscellaneous array. Once, all of the studies are checked, the miscellaneous array is sent
 * for creating a HTML document.
 *
 * @param $studies
 */
function identifyStudiesbyMiscDisorders($studies){
    $miscStudies = array();
    foreach($studies as $obj){
        if(!in_array($obj['nct_id'],$GLOBALS['studiesFound'])){
            $miscStudies[$obj['nct_id']]=$obj;

        }
    }
    createHTMLDoc($miscStudies, "1019");
}

/**
 * It creates an HTML document from an array of objects
 *
 * This function accepts $studies, where we store the array of study results, and it also accepts $condition, the name
 * of the condition, gender, or miscellaneous study to use for the name of the HTML doc file. The studies array is looped
 * through, most of the elements are organized using HTML tags. Once all of the studies are organized, the file is saved
 * using the $condition string and the date when it was created.
 *
 * @param $studies
 * @param $condition
 */
function createHTMLDoc($studies, $condition){
    if(empty($studies)){
        echo "there are no studies for ".$condition.".\n";
    }else{
        echo "THERE ARE STUDIES FOR ==================> ".$condition.".\n";
        $doc = new DOMDocument;
        $doc->encoding = 'utf-8';
        $doc->formatOutput = true;
        $doc->loadHTML(mb_convert_encoding("<!DOCTYPE html><html><head><title>nimh_RRStudies_S</title></head><body></body></html>", 'HTML-ENTITIES', 'UTF-8'), LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
        $body = $doc->getElementsByTagName('body')->item(0);
        $body ->appendChild($doc->createElement('h2','Featured Studies'));
        $template = $doc->createDocumentFragment();
        $template->appendXML('<p>Featured studies include only those <strong>currently recruiting participants</strong>. Studies with the most recent start date appear first.</p>');
        $body->appendChild($template);
        $counter = 0;
        foreach ($studies as $nctid => $value) {
            $section = $doc->createElement('section');
            $section->setAttribute('class', 'box');
            $body->appendChild($section);
            $section->appendChild($doc->createElement('h3'));
            $link = $doc->createElement('a');
            $link->setAttribute('href', "https://clinicaltrials.gov/ct2/show/" . $nctid);
            $link->textContent = htmlspecialchars($value['title']);
            $h3 = $doc->getElementsByTagName('h3')->item($counter);
            $h3->appendChild($link);
            if (!empty($value['type'])) {
                $section->appendChild($doc->createElement('strong', 'Study Type: '));
                $section->appendChild(new DOMText($value['type']));
                $section->appendChild($doc->createElement('br'));
            }
            if (!empty($value['date'])) {
                $date = $value['date'];
                $start_date = date("F d, Y", strtotime($date));
                $section->appendChild($doc->createElement('strong', 'Start Date: '));
                $section->appendChild(new DOMText($start_date));
                $section->appendChild($doc->createElement('br'));
            }
            if (!empty($value['locations'])) {
                foreach ($value['locations'] as $location) {
                    $section->appendChild($doc->createElement('strong', 'Location: '));
                    $section->appendChild(new DOMText($location['city'] . ", " . $location['state'] . ", " . $location['country']));
                    $section->appendChild($doc->createElement('br'));
                }
            }
            if (!empty($value['populations'])) {
                foreach ($value['populations'] as $population) {
                    if ($population['hv'] == 'No') {
                        $hv = 'Does Not Accept Healthy Volunteers';
                    } else {
                        $hv = $population['hv'];
                    }
                    $section->appendChild($doc->createElement('strong', 'Eligibility: '));
                    $pop_min = strtolower($population['min']);
                    if(strlen($pop_min)>3){
                        if(trim($population['max'])=='N/A'){
                            $section->appendChild(new DOMText("Ages " . trim(substr($population['min'],0,2)) . " and Older, " . $hv));
                        }else {
                            $section->appendChild(new DOMText("Ages " . trim(substr($population['min'], 0, 2)) . "-" . trim(substr($population['max'], 0, 2)) . ", " . $hv));
                        }
                    }else{
                        $section->appendChild(new DOMText("Ages " . trim($population['min']) . "-" . trim($population['max']) . ", " . $hv));
                    }
                    $section->appendChild($doc->createElement('br'));
                }
            }
            $section->appendChild($doc->createElement('div'));
            $div = $doc->getElementsByTagName('div')->item($counter++);
            $div->appendChild($doc->createElement('p', htmlspecialchars($value['summary'])));
        }
        //$current_time = date("mdy");
        //$doc_html_name = $condition . '_' . $current_time . '.html';
        $doc_html_name = $condition.'.html';
        $full_path = '/var/www/html/nimh.nih.gov/public_html/ecb-tools/clinical-trials/html/includes/';
        $html_doc = $full_path.$doc_html_name;
        if (file_exists($html_doc)){
            unlink($html_doc);
            $doc->save('/var/www/html/nimh.nih.gov/public_html/ecb-tools/clinical-trials/html/includes/' . $doc_html_name);
        }else {
            $doc->save('/var/www/html/nimh.nih.gov/public_html/ecb-tools/clinical-trials/html/includes/' . $doc_html_name);
        }
    }
}

/**
 * It removes the first line of all HTML documents in the 'includes' directory.
 *
 * This function iterates through all of the files in the 'includes' folder, and it removes the first line, which
 * is an xml declaration, from each file.
 *
 */
function cleanFiles(){
    $fileSystemIterator = new FilesystemIterator(__DIR__.'/includes', FilesystemIterator::CURRENT_AS_PATHNAME);

    foreach ($fileSystemIterator as $file){
        $contents = file($file);
        unset($contents[0]);
        file_put_contents($file, $contents);
    }
}