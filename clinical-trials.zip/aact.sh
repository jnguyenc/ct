#! /usr/bin/bash
/usr/bin/php /var/www/html/nimh.nih.gov/public_html/ecb-tools/clinical-trials/html/aact_conn_obj_ref.php